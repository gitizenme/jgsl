package test;

import javassist.*;

public class Test {

    public static void main(String[] args) throws Exception {
        Object obj = new Object() { int k; };
        ClassPool cp = ClassPool.getDefault();
        CtClass out = cp.get("test.Test");
        CtClass inner = cp.get("test.Test$1");
        System.out.println(out.getName());
        System.out.println(inner.getDeclaringClass().getName());
    }
}
